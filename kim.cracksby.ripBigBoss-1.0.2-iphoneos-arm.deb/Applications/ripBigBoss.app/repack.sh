tmp="$1"
echo "tmp tmp wow"
cd "$tmp/controls"
tar -czvf ../control.tar.gz .
mv "$tmp/controls/control.tar.gz" "$tmp"

cd "$tmp/data"
tar -czvf ../data.tar.gz .
#mv "$tmp/data/data.tar.gz" "$tmp"

ls "$tmp"
cd "$tmp"
ar r "$2" debian-binary control.tar.gz data.tar.gz

echo "#done"

