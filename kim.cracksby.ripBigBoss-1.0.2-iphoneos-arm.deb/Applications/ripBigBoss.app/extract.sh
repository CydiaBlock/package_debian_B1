#!/bin/bash
rm /tmp/file_list*
rm -r /tmp/repack*
origin=$PWD
tmp="/tmp/repack$RANDOM"
rm -r "$tmp"
mkdir "$tmp"
mkdir -p "$tmp/controls"
mkdir -p "$tmp/data"

deb="$1"
for FILE in $(ar t "$deb")
do
  case $FILE in
    control.tar.gz) ar p "$deb" control.tar.gz|tar --extract --gzip  --directory "$tmp/controls";;
    data.tar)       ar p "$deb" data.tar      |tar --extract         --directory "$tmp/data";;
    data.tar.gz)    ar p "$deb" data.tar.gz   |tar --extract --gzip  --directory "$tmp/data";;
    data.tar.bz2)   ar p "$deb" data.tar.bz2  |tar --extract --bzip2 --directory "$tmp/data";;
    data.tar.xz)    ar p "$deb" data.tar.xz   |tar --extract --xz    --directory "$tmp/data";;
    data.tar.lzma)  ar p "$deb" data.tar.lzma |tar --extract --lzma  --directory "$tmp/data";;
	*) 
		ar p "$deb" debian-binary > "$tmp/debian-binary"
	;;
  esac
done

rm "$tmp/data.tar.*" "$tmp/control.tar.*"
cd "$tmp"


find . -type f >> /tmp/file_list2

while read line; do
	file "$line" | grep 'Mach-O' &>/dev/null
	if [ "$?" -ne 0 ]; then
		continue
	fi
	echo "$tmp/$line" >> /tmp/file_list3
done < /tmp/file_list2
echo "$tmp"