#!/bin/bash

killall Installous
killall Installous_

mv Installous Installous_
mv Installous_Launch Installous

chmod 4777 Installous_
chmod 4777 Installous
