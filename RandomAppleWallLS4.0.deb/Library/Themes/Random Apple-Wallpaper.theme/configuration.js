
var LOCK_WPNUM = 31; 

var LOCK_WALLPATH = "Lockscreen/"; 

var LOCK_IMGTYPE = "jpg";
