

/*---------------------------------------------------------------------------------- //  Language  \*/

/*	Here is where you edit the Language of the displayed Days and Months to change
    them all you need to do is copy you language and pastes it in between ( and ).  */

var this_weekday_name_array = new Array( "Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag" )
var this_month_name_array = new Array( 
"Januar","Februar","M�rz","April","mag","Juni","Juli","August","September","Oktober","November","Dezember" )

/*					Language List

1. English
"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"
"January","February","March","April","May","June","July","August","September","October","November","December"

2. French
"Dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"
"Janvier","f�vrier","mars","avril","peut","juin","juillet","ao�t","septembre","octobre","novembre","d�cembre"

3. German
"Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"
"Januar","Februar","M�rz","April","mag","Juni","Juli","August","September","Oktober","November","Dezember"

4. Italian
"Domenica","luned�","marted�","mercoled�","gioved�","venerd�","sabato"
"Gennaio","febbraio","marzo","aprile","pu�","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre"

5. Spanish
"Domingo","lunes","martes","mi�rcoles","jueves","viernes","s�bado"
"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"

6. Dutch
"Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag"
"Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December"

*/
/*
*/
/*
*/

function init ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("clock").appendChild ( timeDisplay );
}

function updateClock ( )
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

/*---------------------------------------------------------------------------------- //  24 hr or 12 hr  \*/

/*	Here is where you edit the Time format 12 hour or 24 to change
    to 12 hour please remove the (*) from the line below to change
    to 24 hour leave (*) on the line below.  */

/*

  // Choose either "AM" or "PM" as appropriate
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

  // Convert the hours component to 12-hour format if needed
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

*/

  // Compose the string for display
  var currentTimeString = currentHours + ":" + currentMinutes;

  // Update the time display
  document.getElementById("clock").firstChild.nodeValue = currentTimeString;

}

/*
*/
/*
*/
/*
*/

function init2 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("ampm").appendChild ( timeDisplay );
}

function amPm ( )
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

/*---------------------------------------------------------------------------------- //  AM or PM  \*/

/*	Here is where you edit the AM, PM Diplay to change
    Enable please remove the (*) from the line below to change
    to Disable leave (*) on the line below.  */

/*

  // Choose either "AM" or "PM" as appropriate
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

  // Convert the hours component to 12-hour format if needed
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

  // Compose the string for display
  var currentTimeString = timeOfDay;

  // Update the time display
  document.getElementById("ampm").firstChild.nodeValue = currentTimeString;

*/
}

/*
*/
/*
*/
/*
*/

function init3 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("calendar").appendChild ( timeDisplay );
}

function calendarDate ( )
{

var this_date_timestamp = new Date()    

var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()    
var this_month = this_date_timestamp.getMonth()    
var this_year = this_date_timestamp.getYear()    

if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;

/*---------------------------------------------------------------------------------- //  Calender Format  \*/

/*	Here is where you edit the Calendar Format to change
    choose your format from the list and copy and paste
    it after the = sign.
    
    Please note if you select Day+Month+Date you will need to move its position  */

	document.getElementById("calendar").firstChild.nodeValue = this_date + ", " + this_month_name_array[this_month]

/*
					Calendar List

1. Day_Month_Date
this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date

2. Day_Month
this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month]

3. Day
this_weekday_name_array[this_weekday]

4. Day_Date 
this_weekday_name_array[this_weekday] + ", " + this_date

5. Month_Date
this_month_name_array[this_month] + " " + this_date

6. Date_Month
this_date + ", " + this_month_name_array[this_month]

*/
}

/*
*/
/*
*/
/*
*/

function init4 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("DayUpdate").appendChild ( timeDisplay );
}

function DayUpdate ( )
{

var this_date_timestamp = new Date()    

var this_weekday = this_date_timestamp.getDay()     

/*---------------------------------------------------------------------------------- //  Day Format  \*/

/*	Here is where you edit the Day Format to change
    choose your format from the list and copy and paste
    it after the = sign.
    
    Please note if you select Day+Month+Date you will need to move its position  */

	document.getElementById("DayUpdate").firstChild.nodeValue = this_weekday_name_array[this_weekday]

/*
					Calendar List 2

1. Day_Month_Date
this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date

2. Day_Month
this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month]

3. Day
this_weekday_name_array[this_weekday]

4. Day_Date 
this_weekday_name_array[this_weekday] + ", " + this_date

5. Month_Date
this_month_name_array[this_month] + " " + this_date

6. Date_Month
this_date + ", " + this_month_name_array[this_month]

*/
}
