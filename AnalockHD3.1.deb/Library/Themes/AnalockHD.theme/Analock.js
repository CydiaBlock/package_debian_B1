/******************************************************

	AnalockHD v3.0
	
	Thanks for all the support - it's been HUGE!
	Special thanks to MacRumors.com
	Special thanks to ModMyI.com
	More special thanks to ihackthatifone.com !!
	
	CHANGELOG
	-------------------------
	
	v3.0
	-----------
		> Now configurable via Safari :)
	
	v2.1.2
	-----------
		> Minor bug fixes from v2.1
		
	v2.1
	-----------
		> Ability to turn weather off completely
		
	v2.0
	-----------
		> Loads more options added
		> Set colours/text/numeric etc.
		
	v1.0
	-----------
		> Working analogue clock!

******************************************************/

var lastUpdatedWeather = 0;

//Default values used to create missing database
var thObj = {
	db: "",
	YWCode: "32452",
	updateWeatherEvery: 60,
	tempUnit: 'c',
	showWeatherImage: 1,
	numericClock: 0,
	colour: "red",
	clockText: "iPhone"
}

//Update the clock with the current time
function updateTime(){
	document.getElementById('text').innerHTML = thObj.clockText;
	document.getElementById('temp').setAttribute("class", thObj.colour);
	document.getElementById('secondHand').setAttribute("class", thObj.colour);
	if (thObj.numericClock) setNumeric();
	if (thObj.showWeatherImage && thObj.updateWeatherEvery > 0) document.getElementById('weatherIcon').style.display = 'block';
	var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
	var now = new Date();
	var day = days[now.getDay()];
	var date = now.getDate() < 10 ? '0'+now.getDate() : now.getDate();
	var h = now.getHours();
	var m = now.getMinutes();
	var s = now.getSeconds();
	var throughHour = findThrough('hour', m);
	var throughMin = findThrough('min', s);
	
	document.getElementById('day').innerHTML = day;
	document.getElementById('date').innerHTML = date;
	
	var hRotate = (h*30)+throughHour;
	var mRotate = (m*6)+throughMin;
	var sRotate = s*6;
	
	document.getElementById('hourHand').style.webkitTransform = "rotate("+hRotate+"deg)";
	document.getElementById('minuteHand').style.webkitTransform = "rotate("+mRotate+"deg)";
	document.getElementById('secondHand').style.webkitTransform = "rotate("+sRotate+"deg)";
	
	if (thObj.updateWeatherEvery > 0)
		if ((lastUpdatedWeather == 0) || (now.getTime() - lastUpdatedWeather >= thObj.updateWeatherEvery))
		{
			fetchWeatherData();
			lastUpdatedWeather = now.getTime();
		}
}

//Update the weather information
function updateWeather(wtrObj){
	if (wtrObj.error)
	{
		document.getElementById('location').innerHTML = "Unknown";
		document.getElementById('temp').innerHTML = "NA";
		if (showWeatherImage)
			document.getElementById('weatherIcon').setAttribute('src', 'images/weather/'+wtrImages[48]+'.png');
	}
	else
	{
		document.getElementById('location').innerHTML = wtrObj.city;
		document.getElementById('temp').innerHTML = wtrObj.temp+"&deg;";
		if (thObj.showWeatherImage)
			document.getElementById('weatherIcon').setAttribute('src', 'images/weather/'+wtrImages[wtrObj.image]+'.png');
	}
}

//Finds how far through the hour/minute we are
function findThrough(unit, val){
	if (val == 0) return 0;
	var working = (1/(60/val))*100;
	if (unit == 'hour') return Math.floor((6/100)*working)*6;
	return Math.floor((6/100)*working);
}

//Change to numeric clock
function setNumeric(){
	document.getElementById('top').innerHTML = '12';
	document.getElementById('right').innerHTML = '3';
	document.getElementById('bottom').innerHTML = '6';
	document.getElementById('left').innerHTML = '9';
}

//Force database clear
function formatDb(){
	thObj.db.transaction(function(tx){
		tx.executeSql("DROP TABLE `config`", [], function(){alert("FORMATTED DATABASE!")}, function(){alert("FORMAT DATABASE FAILURE!")})
	});
}

//Set the config for the Analock object, or setup as default
function getConfig(){
	thObj.db.transaction(function(tx){
		tx.executeSql("SELECT * FROM `config` WHERE `PKEY` = '1'", [], setConfigVals, createDefaultConfig);
	});
}

//Create a default config table
function createDefaultConfig(tx, results){
	thObj.db.transaction(function(tx){
		tx.executeSql("CREATE TABLE `config` (`PKEY` INT(1) NOT NULL DEFAULT '1',`YWCODE` INT(8) NOT NULL,`UPDATE_INTERVAL` INT(4) NOT NULL,`TEMP_UNIT` CHAR(1) NOT NULL,`SHOW_WEATHER_IMAGE` BOOL NOT NULL,`NUMERIC_CLOCK` BOOL NOT NULL,`COLOUR` VARCHAR(3) NOT NULL,`CLOCK_TEXT` VARCHAR(15) NOT NULL, PRIMARY KEY (`PKEY`))", []);
		tx.executeSql("REPLACE INTO `config` (`YWCODE`, `UPDATE_INTERVAL`, `TEMP_UNIT`, `SHOW_WEATHER_IMAGE`, `NUMERIC_CLOCK`, `COLOUR`, `CLOCK_TEXT`) VALUES (?, ?, ?, ?, ?, ?, ?)", [thObj.YWCode, thObj.updateWeatherEvery, thObj.tempUnit, thObj.showWeatherImage, thObj.numericClock, thObj.colour, thObj.clockText]);
	});
	getConfig();
}

//Set the config
function setConfigVals(tx, results, start){
	thObj.YWCode = results.rows.item(0).YWCODE;
	thObj.updateWeatherEvery = results.rows.item(0).UPDATE_INTERVAL*60*1000;
	thObj.tempUnit = results.rows.item(0).TEMP_UNIT;
	thObj.showWeatherImage = results.rows.item(0).SHOW_WEATHER_IMAGE;
	thObj.numericClock = results.rows.item(0).NUMERIC_CLOCK;
	thObj.colour = results.rows.item(0).COLOUR;
	thObj.clockText = results.rows.item(0).CLOCK_TEXT;
	updateTime();
	setInterval(updateTime,1000);
}

//Called on body load, initialises theme
function init(){
	//Create database variable
	var db = openDatabase("AnalockHD", "3.0", "Analock HD Configuration", 36000);
	thObj.db = db;
	
	//Set the config
	getConfig();
}