function init2 ( )

{

  

timeDisplay = document.createTextNode ( "" );

  

document.getElementById("weekday").appendChild ( timeDisplay );

  

document.getElementById("month").appendChild ( timeDisplay );

  

document.getElementById("season").appendChild ( timeDisplay );
  
  

document.getElementById("season1").appendChild ( timeDisplay );

}







function calendarDate ( )



{

/* Enable (comment/uncomment) one week name string or the other, the bottom one being some stuff i made up to spice it up a bit :p (potentially lame) */


/*   var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday") */
  



var this_weekday_name_array = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")

  

var this_month_name_array = new Array("January","Febrary","March","April","May","June","July","August","September","October","November","December")



/* controls season names, if it doesnt fit your location, you can fis it accordingly to the 12 months starting January */
  

var this_season_name_array = new Array("Invierno","Invierno","Empieza la Primavera","Primavera","Primavera","Empieza el Verano","Verano","Verano","Empieza el Oto�o","Oto�o","Oto�o","Qu� fr�o... Invierno")
    

  

var this_date_timestamp = new Date()	  

  

var this_weekday = this_date_timestamp.getDay()    

  

var this_month = this_date_timestamp.getMonth()

  

var this_season = this_date_timestamp.getMonth()    

   

  

document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday];

  

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month];

  

document.getElementById("season").firstChild.nodeValue = this_season_name_array[this_season];
  
  

document.getElementById("season1").firstChild.nodeValue = this_season_name_array[this_season];

}