#!/bin/sh
#
# DecryptApp - v1.3.6 (2008-11-24)
# uncon
#
# Many thanks to:
#    puy0, SaladFork, Flox, Flawless, HakAttack
#

DisplayHelp() {
	echo "Usage: $(basename $0) [OPTIONS]"
	echo
	echo "Mandatory options:"
	echo "  -a  path to .app directory"
	echo "  -e  executable name (CFBundleExecutable)"
	echo "  -v  application version (CFBundleVersion)"
	echo "  -n  application display name (CFBundleDisplayName)"
	echo
	echo "Other options:"
	echo "  -h  display help"
	echo
}

#echo "DecryptApp 1.3.6 (2008-11-24)"
#echo "uncon"
#echo

if [ $# -eq 0 ]; then
	DisplayHelp
	exit 1
fi

while [ "$1" != "" ]; do
	case $1 in
		-a)
			AppInput="$2"
			shift 2;;
		-e)
			AppExec="$2"
			shift 2;;
		-v)
			AppVer="$2"
			shift 2;;
		-n)
			AppDisplayName="$2"
			shift 2;;
		-h)
			DisplayHelp
			exit 0;;
		*)
			DisplayHelp
			echo "Unrecognized option: $1"
			exit 1;;
	esac
done

echo "0% Checking dependencies"

if [ ! -e /usr/bin/plutil ]; then
	echo "Cannot find plutil (Install 'Erica Utilities' with Cydia)"
	exit 1
fi

if [ ! -e /usr/bin/gdb ]; then
	echo "Cannot find gdb (Install 'GNU Debugger' with Cydia)"
	exit 1
fi

if [ ! -e /usr/bin/otool ]; then
	echo "Cannot find otool (Install 'Darwin CC Tools' with Cydia)"
	exit 1
fi

if [ ! -e /usr/bin/ldid ]; then
	echo "Cannot find ldid  (Install 'Link Identity Editor' with Cydia)"
	exit 1
fi

echo "2% Checking paths"

if [ ! -d "$AppInput" ]; then
	echo "Application directory does not exist ($AppInput)"
	exit 1
fi

AppPath=$(dirname "$AppInput")
AppName=$(basename "$AppInput")

if [ ! -d "$AppPath" ]; then
	echo "Unable to locate sandbox directory ($AppPath)"
	exit 1
fi

if [ ! -d "$AppPath/$AppName" ]; then
	echo "Unable to locate application directory ($AppName)"
	exit 1
fi

if [ "$(echo "$AppName" | awk -F . '{print $NF}')" != "app" ]; then
	echo "Application directory does not end with '.app'"
	exit 1
fi

if [ ! -e "$AppPath/$AppName/$AppExec" ]; then
	echo "Unable to locate executable ($AppExec)"
	exit 1
fi

echo "5% Found $AppName"

echo "10% Creating directories"

WorkDir="/tmp/DecryptApp-$(date +%Y%m%d-%H%M%S)"
NewAppDir="$HOME/Media/DecryptedIPAs"

if [ -e "$WorkDir" ]; then
	rm -rf "$WorkDir"
fi

mkdir -p "$WorkDir"

if [ ! -e "$NewAppDir" ]; then
	mkdir -p "$NewAppDir"
fi

if [ ! -d "$WorkDir" -o ! -d "$NewAppDir" ]; then
	echo "Unable to create Directories"
	exit 1
fi

echo "15% Copying application files"

cp -a "$AppPath/$AppName/" "$WorkDir/"

if [ ! -e "$WorkDir/$AppName/$AppExec" ]; then
	echo "Unable to copy application files"
	rm -fr "$WorkDir"
	exit 1
fi

echo "20% Analyzing application"

CryptID=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID -ne "1" ]; then
	echo "Application is not encrypted"
	rm -fr "$WorkDir"
	exit 1
fi

CryptSize=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptsize | awk '{print $2}')
if [ ! $CryptSize ]; then
	echo "Unable to find CryptSize"
	rm -fr "$WorkDir"
	exit 1
fi

CryptOff=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptoff | awk '{print $2}')
if [ ! $CryptOff ]; then
	echo "Unable to find CryptOff"
	rm -fr "$WorkDir"
	exit 1
fi

echo "30% Patching CryptID"

od -A n -N 4096 -t x1 --w=4096 "$WorkDir/$AppName/$AppExec" | sed 's/ //g' | sed 's/2f7573722f6c69622f64796c64.*/2f7573722f6c69622f64796c64/g' > "$WorkDir/cryptid.hex"
foo=$(printf "\x0" | dd bs=1 conv=notrunc of="$WorkDir/$AppName/$AppExec" seek=$(expr $(($(stat -c%s "$WorkDir/cryptid.hex") + 253)) / 2)  2>&1 > /dev/null)
rm "$WorkDir/cryptid.hex"

CryptID=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID -eq "1" ]; then
	echo "Unable to patch CryptID"
	rm -fr "$WorkDir"
	exit 1
fi

echo "40% Dumping unencrypted data"

echo -e "set sharedlibrary load-rules \".*\" \".*\" none" > "$WorkDir/batch.gdb"
echo -e "set inferior-auto-start-dyld off" >> "$WorkDir/batch.gdb"
echo -e "set sharedlibrary preload-libraries off" >> "$WorkDir/batch.gdb"
echo -e "set sharedlibrary load-dyld-symbols off" >> "$WorkDir/batch.gdb"
echo -e "handle all nostop" >> "$WorkDir/batch.gdb"
echo -e "break *0x2000" >> "$WorkDir/batch.gdb"
echo -e "commands 1" >> "$WorkDir/batch.gdb"
echo -e "dump memory $WorkDir/dump.bin 0x2000 $(($CryptSize + 0x2000))" >> "$WorkDir/batch.gdb"
echo -e "kill" >> "$WorkDir/batch.gdb"
echo -e "quit" >> "$WorkDir/batch.gdb"
echo -e "end" >> "$WorkDir/batch.gdb"
echo -e "start" >> "$WorkDir/batch.gdb"
foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x "$WorkDir/batch.gdb" -batch 2>&1 > /dev/null)
rm -f "$WorkDir/batch.gdb"

echo "50% Verifiying data dump"

DumpSize=$(stat -c%s $WorkDir/dump.bin)
if [ "$DumpSize" != "$CryptSize" ]; then
	echo "Memory dump is not the right size or does not exist"
	rm -fr "$WorkDir"
	exit 1
fi

foo=$(dd if=/dev/zero of="$WorkDir/zero.bin" bs=$DumpSize count=1 2>&1 > /dev/null)
diff "$WorkDir/zero.bin" "$WorkDir/dump.bin" 2>&1 > /dev/null
if [ $? -eq 0 ]; then
	echo "Memory dump is invalid"
	rm -fr "$WorkDir"
	exit 1
fi
rm -f "$WorkDir/zero.bin"

echo "55% Replacing encrypted data with data dump"

foo=$(dd seek=4096 bs=1 conv=notrunc if="$WorkDir/dump.bin" of="$WorkDir/$AppName/$AppExec" 2>&1 > /dev/null)
rm "$WorkDir/dump.bin"

echo "60% Signing the application"

foo=$(ldid -s "$WorkDir/$AppName/$AppExec" 2>&1 > /dev/null)
plutil -s 'SignerIdentity' -v 'Apple iPhone OS Application Signing' "$WorkDir/$AppName/Info.plist" 2>&1 > /dev/null

if [ -e "$WorkDir/$AppName/SC_Info" ]; then
	echo "61% Removing SC_Info"
	rm -fr "$WorkDir/$AppName/SC_Info"
fi

if [ -e "$WorkDir/$AppName/_CodeSignature" ]; then
	echo "62% Removing _CodeSignature"
	rm -fr "$WorkDir/$AppName/_CodeSignature"
fi

if [ -h "$WorkDir/$AppName/CodeResources" ]; then
	echo "63% Removing CodeResources"
	rm -fr "$WorkDir/$AppName/CodeResources"
fi

if [ -e "$WorkDir/$AppName/ResourceRules.plist" ]; then
	echo "64% Removing ResourceRules.plist"
	rm -fr "$WorkDir/$AppName/ResourceRules.plist"
fi

echo "65% Building .ipa"

mkdir -p "$WorkDir/Payload"
if [ ! -e "$WorkDir/Payload" ]; then
	echo "Failed to create Payload directory"
	rm -fr "$WorkDir"
	exit 1
fi
mv "$WorkDir/$AppName" "$WorkDir/Payload/"

echo "70% Copying iTunesArtwork"

if [ -e "$AppPath/iTunesArtwork" ]; then
	cp -a "$AppPath/iTunesArtwork" "$WorkDir/"
else
	echo "Unable to find iTunesArtwork"
fi

echo "75% Compressing the .ipa"

IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: :_:g")-v$AppVer.ipa
cd "$WorkDir"
zip -m -r "$IPAName" * 2>&1 > /dev/null
cd - 2>&1 > /dev/null
if [ ! -e "$IPAName" ]; then
	echo "Failed to compress the .ipa"
	rm -fr "$WorkDir"
	exit 1
fi

echo "95% Removing temporary files"

rm -rf "$WorkDir"

echo "100% Done"

echo "Created decrypted .ipa at $IPAName"
exit 0
