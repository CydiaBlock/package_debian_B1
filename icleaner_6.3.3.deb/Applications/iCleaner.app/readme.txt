_------------------------------------_
_          iCleaner v6.3.3           _
_  http://exile90software.com/cydia  _
 ------------------------------------
The ultimate iDevice cleaning app! It removes unnecessary files from your device.


What does this do?
--------------------------------------
- CLEANUP: iCleaner can remove unnecessary files from your device. The cleanup process is made of the following steps:

1) Safari: it deletes cookies, browsing history and cache files to free up memory and preserve your privacy.

2) Applications: it deletes unnecessary AppStore apps caches, cookies, temporary files and snapshots.
Furthermore, it detects popular applications for a more in-depth cleanup. Check the website for info about the supported applications.
More apps are added with each subsequent release. User login data, useful cookies and other relevant files are left untouched. iCleaner only removes the unnecessary.

3) Cydia: it cleans up Cydia caches and temporary files, Cydia applications unnecessary files, partially downloaded Cydia packages and repo files.

4) Cydia sources (disabled by default): it deletes Cydia sources files. As a result, Cydia will not list any package and the sources will have to be updated. This is disabled by default since it's only helpful if Cydia sources aren't updating correctly.

5) Unused dependencies (disabled by default): issues the "apt-get autoremove" command in order to remove packages installed as dependencies that are not needed anymore.
Additionally, it removes preference files left by some uninstalled packages and removes unneeded entries from the "/var/lib/dpkg/status" file.
This is disabled by default since it should only be used by experienced users who want to automate the operation. Note that removed packages and preferences are not included in the "analyze" filesize count.

6) Log files: it deletes log files and crash reports from known locations. These files are generally irrelevant to the user and can be safely deleted.

7) Cache files: it scans and deletes system cache files and databases. Some of them are rebuilt upon respring. This helps removing obsolete cache data.

8) Temporary files: it deletes temporary files from your device. These files are meant to be removed automatically, but they often happen not to. iCleaner takes care of that.

9) Filetype cleanup: iCleaner features a custom cleanup pass based on file extensions. By default, it looks for log and temp files all over the directory tree.
You might want to add more extensions (such as "bak" or "old"), but remember to use this with caution!
Also, note that iCleaner will not allow usage of non-alphanumeric characters and some disallowed extensions via GUI (disallowed ones will be removed as you confirm), while it accepts anything via terminal (wildcards too).


- LANGUAGES / KEYBOARDS/ VOICES REMOVAL: with these tools you can easily remove all of the languages you don't need from your iDevice! Just select the languages you wish to remove, then tap on "Remove languages".
Starting from version 6.0.0, you can also remove keyboards (textinput files) and voice control languages. These tools will only remove the ones you selected in the "Languages to remove" menu.
No more terminal scripts! Configure it once, and remove language files whenever you want!

NOTE 1: English cannot be removed as a security feature.
NOTE 2: iCleaner will not allow you to delete your own language in most cases, but please double check it. If you remove your own language, and want it back, you'll have to restore your device.
NOTE 3: languages will be installed whenever you install/update apps or tweaks. Therefore, this tool has to be run periodically.
NOTE 4: "keyboards" refer to "international keyboards", the ones you can configure in "Settings - General - Keyboard - International keyboards". They will still appear in the list, but won't work if removed.


- RETINA / NON-RETINA / IPAD / 4" / ITUNESARTWORK IMAGES REMOVAL: these tools allow you to remove device-specific and unnecessary images from your iDevice. For example, iPad images are not needed on iPhone and iPod, and can be safely removed.
Caution is advised with them though, a "Test Mode" run is very recommended (especially when using "remove non-retina images", which can easily break some applications).

iTunesArtwork files are only needed for ad-hoc distribution, display on the AppStore and iTunes library. They serve no purpose on the device. Every app you install has one, and it can be safely removed.
As a result, however, iTunes won't show artworks for apps in the library. If you want to view the artworks, please "transfer your purchases" on iTunes before removing iTunesArtwork files.

By default, iCleaner scans for images in "/Applications/" and "/var/mobile/Applications/". It does not scan the whole disk since that might easily break something on some configurations.
If you want to add more folders, just edit the "/var/mobile/Library/iCleaner/imgdirs.txt" file. Make sure to add a newline at the end of the file and a "/" at the end of every folder path, as they're necessary to let iCleaner work properly.

Specific applications can be excluded in the "Excluded apps" menu. The correct procedure for using this function is: running it in "Test Mode"; check all of your apps, to see if any of them has been broken;
restore the backup files; exclude the apps that were broken; finally, run it without test mode.

NOTE 1: please note that deleting images (and languages) will also affect apps .ipa files that are transferred to iTunes. This is especially important if you synchronize your apps to both your iPhone and iPad, as deleting iPad images on your iPhone will break the app on your iPad.
Same story if you have both a 3.5" and a 4" device. To avoid this, it's mandatory that you "transfer your purchases" on iTunes before you use iCleaner to remove images and/or languages.
NOTE 2: 4" refers to 4-inch display devices such as iPhone 5 and iPod Touch 5th gen.


- WALLPAPERS MANAGEMENT: this tool allows you to remove the stock wallpapers that come with your iOS device. You can tap to see previews, and just swipe to remove them one by one! You can free up a considerable amount of space by removing them.


- MOVE FONTS FOLDER: iCleaner can move the huge "Fonts" folder to/from the System partition, which has very limited space. Please note that no space is gained during this process, as the folder is just moved.
Of course, fonts will still be readable by iOS. The folder is moved and then replaced with a symbolic link to the new location, so everything will work just as before. You can bring it back to its original location by re-running this tool.


More Info:
--------------------------------------
Check the project website (http://exilecom.altervista.org/cydia/icleaner) for further info, FAQs, troubleshooting or to display the full changelog.


Support:
--------------------------------------
If you have questions or issues about iCleaner, just visit the project page (http://exilecom.altervista.org/cydia/icleaner) and check the "Troubleshooting" section, or send me an email at "exile@live.it".


Disclaimer:
--------------------------------------
IMPORTANT - PLEASE READ: by using iCleaner (referred to as "the Software"), you agree to be bound to these terms between you and Ivano Bilenchi (referred to as "the Licensor"). If you do not agree to these terms, do not use the software product.

The Software is provided "AS IS", without warranty of any kind, including without limitation the warranties of merchantability, fitness for a particular purpose and non-infringement.
The Licensor makes no warranty that the Software is free of defects or is suitable for any particular purpose.
In no event shall the Licensor be responsible for loss or damages arising from the installation or use of the Software, including but not limited to any indirect, punitive, special, incidental or consequential damages of any character including, without limitation, device failure or malfunction, or any other commercial damages or losses.

