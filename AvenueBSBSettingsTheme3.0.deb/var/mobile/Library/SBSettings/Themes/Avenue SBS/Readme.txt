1) Upload the SBSettings folder to /private/var/mobile/library/sbsettings/themes.
2) Apply the theme via sbsettings->more->manage themes.


