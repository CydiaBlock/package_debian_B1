#!/bin/sh
#
# IDApp - v1.1 (2008-11-21)
# uncon
#

DisplayHelp() {
	echo "Usage: $(basename $0) [OPTIONS]"
	echo
	echo "Mandatory options:"
	echo "  -i  IPA file to examine"
	echo "  -k  property list key to find"
	echo
	echo "Other options:"
	echo "  -h  display help"
	echo
}

echo "IDApp 1.1 (2008-11-21)"
echo "uncon"
echo

if [ $# -eq 0 ]; then
	DisplayHelp
	exit 1
fi

PLKey=CFBundleIdentifier

while [ "$1" != "" ]; do
	case $1 in
		-i)
			IPAInput="$2"
			shift 2;;
		-k)
			PLKey="$2"
			shift 2;;
		-h)
			DisplayHelp
			exit 0;;
		*)
			DisplayHelp
			echo "Unrecognized option: $1"
			exit 1;;
	esac
done

if [ ! -f "$IPAInput" ]; then
	echo "IPA file does not exist ($IPAInput)"
	exit 1
fi

if [ "$PLKey" = "" ]; then
	echo "No property list key to find"
	exit 1
fi

PListTemp="/tmp/InstallApp-$(date +%Y%m%d-%H%M%S).plist"
unzip -p "$IPAInput" $(unzip -l "$IPAInput" | egrep "Payload/[^/]*/Info.plist" | awk '{ print $4 }') > "$PListTemp"

if [ $? -gt 0 ]; then
	echo "Unable to decompress archive"
	rm -fr "$PListTemp"
	exit 1
fi

AppId=$(plutil -key "$PLKey" "$PListTemp" 2>&1)
rm -f "$PListTemp"

if [ "$AppId" = "" ]; then
	echo "Unable to find $PLKey"
	exit 1
fi

echo -e "$AppId"
exit 0
