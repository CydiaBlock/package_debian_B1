#!/bin/sh
#
# InstallAppLight.sh  1.0 (2008-10-27)
# puy0 (puyopo@gmail.com)
#
# this is a mix between :
#    - old Installous (pre 1.2) script (thx Flawless)
#    - new Installous script by uncon
#

echo -e "> InstallAppLight 1.0 - puy0\n"

AppName=$(basename "$1")
AppPath=$(dirname "$1")
UUID=$(uuid -v4 | tr "[:lower:]" "[:upper:]")
AppNewPath=/var/mobile/Applications/$UUID

echo "0% Processing $AppName"

echo "10% Decompressing archive"
unzip -qq "$AppPath/$AppName" -d "$AppNewPath"
if [ $? -gt 0 ]; then
	echo -e "\n> Script failed. Unable to decompress archive."
	rm -fr "$AppNewPath"
	exit 1
else
	cd "$AppNewPath"
	echo "50% Relocating application directory"
	mv Payload/* . && rmdir Payload
	echo "70% Building application directories"
	mkdir Library Documents tmp
	echo "80% Fixing permissions"
	chmod -R 775 "$AppNewPath"
	echo -e "100% \n> Script completed. Installed $AppName to \n$AppNewPath"
fi

