-------------------------
Windows_XP_Fix.exe ReadMe
-------------------------

--------------------
INSTALL INSTRUCTIONS
--------------------

1)  Copy the Windows_XP_Fix.exe from your iPhone to your Windows Desktop
2)  Run the Windows_XP_Fix.exe
3)  The Console Window might ask for a Reboot - if so reboot your PC
4)  Windows should recognize a new device - your iPhone with an icon showing a mp3-player or similar
--> 5a) You are done

--> 5b) If Windows does not recognize it: reboot your PC
6)  Run the Windows_XP_Fix.exe again
7)  Windows should recognize a new device - your iPhone with an icon showing a mp3-player or similar

----------------------------------------------
WHAT IS Windows_XP_Fix.exe DOING TO MY SYSTEM?
----------------------------------------------

Some may ask what Windows_XP_Fix.exe might do to their system and if they want it to do this.

So here is what it does:

- Windows_XP_Fix.exe is a self-extracting WinRar-archive
- After extracting into temp dir it executes a *.bat file
- This *.bat file performs:
	- the installation of Microsoft's Windows Portable Device driver which is included with Windows Media Player 11 installation (skipped when already installed)
	- the installation of a *.inf file which will assign the default Windows MTP (Media Transfer Protocol) Driver to the iPhone (instead of Windows XP's old PTP driver)

That is all that happens. All executables are authentic Microsoft ones and can be MD5 checked.
The batch script is plain text to be easily checked by everyone.