#!/bin/bash
home=$(dirname "$0")

if [ `uname -m | grep iPhone2` ]; then
	exec "${home}"/yxflash2
else
	exec "${home}"/yxflash
fi
