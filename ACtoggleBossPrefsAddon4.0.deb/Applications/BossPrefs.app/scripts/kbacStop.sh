#!/bin/sh
mv /System/Library/TextInput /System/Library/TextInput.bak
/usr/bin/killall MobileSafari

#Made by Yuri2017. Tutti i Diritti Riservati.