#!/bin/sh
mv /System/Library/TextInput.bak /System/Library/TextInput
/usr/bin/killall MobileSafari

#Made by Yuri2017. Tutti i Diritti Riservati.