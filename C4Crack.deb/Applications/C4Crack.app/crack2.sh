#!/bin/bash

AppInput=$1

echo "1"
tempLoc=$(find /var/mobile/Applications -iname "$AppInput")
if [ -z "$tempLoc" ]; then
	echo "1337" 
	echo "Cannot Find $AppInput"
	exit 1
fi
AppCount=$(find /var/mobile/Applications -iname "$AppInput" | wc -l)
if [ $AppCount -gt 1 ]; then
	echo "1337" 
	echo "Found Multiple Install Locations."
	exit 1
fi

AppPath=$(dirname "$tempLoc")
AppName=$(basename "$tempLoc")
AppExec=$(plutil -key CFBundleExecutable "$tempLoc/Info.plist" 2>&1)
AppVer=$(plutil -key CFBundleVersion "$tempLoc/Info.plist" 2>&1)
AppDisplayName=$(plutil -key CFBundleDisplayName "$tempLoc/Info.plist" 2>&1)

if [ ! -d "$AppPath" ]; then
	echo "1337"
	echo "Unable to Find Install Location"
	exit 1
fi
if [ ! -d "$AppPath/$AppName" ]; then
	echo "1337"
	echo "Unable to Find App Location"
	exit 1
fi

if [ ! -e "$AppPath/$AppName/$AppExec" ]; then
	echo "1337"
	echo "Unable to Find Executable"
	exit 1
fi

echo "2"
WorkDir="/tmp/DecryptApp-$(date +%Y%m%d-%H%M%S)"
NewAppDir="$HOME/Cracked"

if [ -e "$WorkDir" ]; then
	rm -rf "$WorkDir"
fi

mkdir -p "$WorkDir"

if [ ! -e "$NewAppDir" ]; then
	mkdir -p "$NewAppDir"
	chmod 777 "$NewAppDir"
fi

if [ ! -d "$WorkDir" -o ! -d "$NewAppDir" ]; then
	echo "1337"
	echo "Unable to Create Workspace"
	exit 1
fi

echo "3"

cp -a "$AppPath/$AppName/" "$WorkDir/"

if [ ! -e "$WorkDir/$AppName/$AppExec" ]; then
	echo "1337"
	echo "Unable to Set up Application"
	rm -fr "$WorkDir"
	exit 1
fi

echo "4"

CryptSize=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptsize | awk '{print $2}')
if [ ! $CryptSize ]; then
	echo "1337"
	echo "Unable to Find CryptSize"
	rm -fr "$WorkDir"
	exit 1
fi

CryptOff=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptoff | awk '{print $2}')
if [ ! $CryptOff ]; then
	echo "1337"
	echo "Unable to Find CryptOff"
	rm -fr "$WorkDir"
	exit 1
fi

CryptID=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID -ne "1" ]; then
	echo "1337"
	echo "Application is Already Cracked or in Beta"
	rm -fr "$WorkDir"
	exit 1
fi


echo "5"

# "/System/Library/Frameworks" in hex
PathAsHex="2f53797374656d2f4c6962726172792f4672616d65776f726b73"

# - Convert to hex on 1 long line, only take stuff before the path string,
# - Convert to 1 byte set per line, find 0x01 (line number is offset in the real file),
# - Strip newlines, reverse the order
oneLocations=($(od -A n -t x1 -v "$WorkDir/$AppName/$AppExec" | \
	tr -d ' ','\n' | \
	sed "s/$PathAsHex.*\$//" | \
	sed "s/../&\n/g" | \
	grep -n -s 01 | \
	cut -d : -f 1 | \
	sort -nr | \
	tr "\n" " "))

for TryOffset in "${oneLocations[@]}"; do
	cp -a "$WorkDir/$AppName/$AppExec" "$WorkDir/$AppName/$AppExec.trying"
	foo=$(echo -ne "\x00" | dd bs=1 seek=$((TryOffset - 1)) conv=notrunc status=noxfer of="$WorkDir/$AppName/$AppExec.trying" 2>&1> /dev/null)
	cid=$(otool -l "$WorkDir/$AppName/$AppExec.trying" | grep cryptid | awk '{print $2}')
	if [ $cid -eq 0 ]; then
		break
	fi
	rm "$WorkDir/$AppName/$AppExec.trying"
done

if [ ! -e "$WorkDir/$AppName/$AppExec.trying" ]; then
	echo "1337"
	echo "Unable to patch CryptID"
	rm -fr "$WorkDir"
	exit 1
fi

mv "$WorkDir/$AppName/$AppExec.trying" "$WorkDir/$AppName/$AppExec"

echo "6"

echo -e "set sharedlibrary load-rules \".*\" \".*\" none\r\n\
set inferior-auto-start-dyld off\r\n\
set sharedlibrary preload-libraries off\r\n\
set sharedlibrary load-dyld-symbols off\r\n\
handle all nostop\r\n\
break *0x2000\r\n
commands 1\r\n\
dump memory $WorkDir/dump.bin 0x2000 $(($CryptSize + 0x2000))\r\n\
kill\r\n\
quit\r\n\
end\r\n\
start" > $WorkDir/batch.gdb

foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x $WorkDir/batch.gdb -batch 2>&1> /dev/null)

rm $WorkDir/batch.gdb

echo "7"

DumpSize=$(stat -c%s "$WorkDir/dump.bin")
if [ "$DumpSize" != "$CryptSize" ]; then
	echo "1337"
	echo "Memory Dump is Corrupt or Doesn't Exist"
	rm -fr "$WorkDir"
	exit 1
fi

foo=$(dd seek=4096 bs=1 conv=notrunc if="$WorkDir/dump.bin" of="$WorkDir/$AppName/$AppExec" 2>&1> /dev/null)
rm "$WorkDir/dump.bin"

echo "8"
foo=$(ldid -s "$WorkDir/$AppName/$AppExec" 2>&1> /dev/null)

if [ -e "$WorkDir/$AppName/SC_Info" ]; then
	rm -fr "$WorkDir/$AppName/SC_Info"
fi

if [ -e "$WorkDir/$AppName/_CodeSignature" ]; then
	rm -fr "$WorkDir/$AppName/_CodeSignature"
fi

if [ -h "$WorkDir/$AppName/CodeResources" ]; then
	rm -fr "$WorkDir/$AppName/CodeResources"
fi

if [ -e "$WorkDir/$AppName/ResourceRules.plist" ]; then
	rm -fr "$WorkDir/$AppName/ResourceRules.plist"
fi


echo "9"

mkdir -p "$WorkDir/Payload"
if [ ! -e "$WorkDir/Payload" ]; then
	echo "1337"
	echo "Cannot Create Payload Folder"
	rm -fr "$WorkDir"
	exit 1
fi
mv "$WorkDir/$AppName" "$WorkDir/Payload/"

echo "10"

if [ -e "$AppPath/iTunesArtwork" ]; then
	cp -a "$AppPath/iTunesArtwork" "$WorkDir/"

if [ -e "$AppPath/iTunesMetadata.plist" ]; then
	cp -a "$AppPath/iTunesMetadata.plist" "$WorkDir/"

IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: :_:g")-v$AppVer.ipa
cd "$WorkDir"
zip -m -r "$IPAName" * 2>&1> /dev/null
cd - 2>&1> /dev/null
if [ ! -e "$IPAName" ]; then
	echo "1337"
	echo "Cannot Compress IPA"
	rm -fr "$WorkDir"
	exit 1
fi

rm -rf "$WorkDir"


echo "149"
