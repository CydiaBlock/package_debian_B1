/*****************************************************
	
	---------------------
	## DESCRIPTION
	---------------------
	
	This fetches the latest tweet of a user.
	The only bit of information stored is the tweet.
	The tweet username is removed.
	
	

	---------------------
	## CHANGELOG
	---------------------
	
	> 17/11/2010 Remove username from tweet
	 
*****************************************************/

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 3(a,b){1 c;m(c=a.8;c!=5;c=c.n)9(c.o==b)6 c;6 5};2 p(){4.q=r;1 a="s://t.u/v/w/"+4.g+".h";1 b=7 x();b.y=2(){j(b)};b.z("A/B");b.C("D",a);b.E("F-G","H-I");b.J(5);6 b};2 j(b){9(b.k){1 c=3(3(3(b.k,"h"),"K"),"L");1 d=7 M(4.g+": ","i");1 e=c.N(\'O\')[0].8.P.Q(d,"");1 f=7 R;4.S.T(2(a){a.U("V W X Y=?, Z=?",[f.10(),e],l)})}11 l()};',62,64,'|var|function|getChild|theObj|null|return|new|firstChild|if|||||||twtrName|rss||gotTweet|responseXML|refreshCache|for|nextSibling|nodeName|fetchTweet|fetchingTwtr|true|http|twitter|com|statuses|user_timeline|XMLHttpRequest|onload|overrideMimeType|text|xml|open|GET|setRequestHeader|Cache|Control|no|cache|send|channel|item|RegExp|getElementsByTagName|title|nodeValue|replace|Date|db|transaction|executeSql|UPDATE|CACHES|SET|LAST_TWITTER_UPDATE|CACHE_TWEET|getTime|else'.split('|'),0,{}))