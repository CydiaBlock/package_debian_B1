/*****************************************************

	---------------------
	## CHANGELOG
	---------------------
	
	v1.3
	---------
	  > Improved 12 hour functionality
	
	v1.2
	---------
	  > 12 hour clock option
	
	v1.1
	---------
	  > Twitter - added!
	
	v1.0
	---------
	  > Script made
	 
*****************************************************/

var months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];


/********************************

	## DO NOT EDIT BELOW HERE
	
********************************/

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('m 17=1.3;m 4={p:"",18:1O,J:\'1P\',K:1,L:1,M:1,19:\'c\',1a:"1Q",N:1b,O:1R,v:0,w:0,x:1S,y:0,z:0,A:0,B:"1T...",C:"1U 1V 1W 1c. 1X 1Y 1Z\'t 20, 21 1t.",1d:P,1e:P};j 1f(){4.p.s(j(a){a.q("1g Q,R,S,T,U,V,W,X,Y 1h Z",[],1u,1v)})};j 1u(a,b){4.18=b.5.6(0).Q;4.J=b.5.6(0).R;4.M=b.5.6(0).Y;4.K=b.5.6(0).S;4.L=b.5.6(0).T;4.19=b.5.6(0).U;4.1a=b.5.6(0).V;4.N=b.5.6(0).W*1b*1i;4.O=b.5.6(0).X*1b*1i;1j()};j 1v(){4.p.s(j(a){a.q("1w 11 1x 1y Z");a.q("1z 11 Z (Q r(8) k l, R 1k(3) k l, S 1l k l, U 22(1) k l, W r(3) k l, T 1l k l, V 1k(15) k l, X r(3) k l, Y 1l k l)");a.q("1A 1B Z (Q, R, S, U, W, T, V, X, Y) 1C (?, ?, ?, ?, ?, ?, ?, ?, ?)",[4.18,4.J,4.K,4.19,4.N,4.L,4.1a,4.O,4.M],1f)})};j 1j(){4.p.s(j(c){c.q("1g * 1h u",[],j(a,b){4.v=b.5.6(0).D;4.x=b.5.6(0).E;4.y=b.5.6(0).F;4.z=b.5.6(0).G;4.A=b.5.6(0).H;4.B=b.5.6(0).I;4.w=b.5.6(0).13;4.C=b.5.6(0).14;1m()},1D)})};j 1E(){4.p.s(j(c){c.q("1g * 1h u",[],j(a,b){4.v=b.5.6(0).D;4.x=b.5.6(0).E;4.y=b.5.6(0).F;4.z=b.5.6(0).G;4.A=b.5.6(0).H;4.B=b.5.6(0).I;4.w=b.5.6(0).13;4.C=b.5.6(0).14;4.1d=P;4.1e=P})})};j 1D(){4.p.s(j(a){a.q("1w 11 1x 1y u");a.q("1z 11 u (D r(12) k l, E r(2) k l, F r(3) k l, G r(3) k l, H r(3) k l, I 1k(23) k l, 13 r(12) k l, 14 24 k l)");a.q("1A 1B u (D, E, F, G, H, I, 13, 14) 1C (?, ?, ?, ?, ?, ?, ?, ?)",[4.v,4.x,4.y,4.z,4.A,4.B,4.w,4.C],1j)})};j 25(b){n(!b.26){m c=1F 1G;4.p.s(j(a){a.q("27 u 28 D=?, E=?, F=?, G=?, H=?, I=?",[c.1H(),b.29,b.1I,b.2a,b.2b,b.2c],1E)})}};j 1m(){m a=1F 1G();m b=a.2d();m c=a.2e();m d=a.2f();m e=a.2g();m f=a.2h();m g=a.2i();m h=a.1H();n(!4.M){m i=b<12?\'2j\':\'2k\';7.9(\'1J\').1n.1o="1p";7.9(\'1J\').o=i;n(b>12)b-=12;n(b==0)b=12;n(b<10)7.9(\'1q\').1r="2l";16 7.9(\'1q\').1r=""}16{n(b<10)b=\'0\'+b}n(c<10)c=\'0\'+c;n(e<10)e=\'0\'+e;d=2m[d];f=2n[f];7.9(\'2o\').1r=4.J;7.9(\'2p\').o=d;7.9(\'1q\').o=b;7.9(\'2q\').o=c;7.9(\'2r\').o=e;7.9(\'2s\').o=f;7.9(\'2t\').o=g;n(4.K){7.9(\'1K\').1n.1o="1p";n(h-4.v>=4.N&&!4.1d)2u();16{7.9(\'2v\').2w="2x/1K/"+2y[4.x]+".2z";7.9(\'1I\').o=4.y+"&1s;";7.9(\'2A\').o=4.z+"&1s;";7.9(\'2B\').o=4.A+"&1s;";7.9(\'2C\').o=4.B}}n(4.L){7.9(\'1c\').1n.1o="1p";n(h-4.w>=4.O&&!4.1e)2D();16 7.9(\'1c\').o=\'"\'+4.C.2E(0,2F)+"..."+\'"\'}2G(1m,1i)};j 2H(){m a=2I("1L","","1L 1t 2J 2K 2L",2M);4.p=a;m b=2N(4.p.1M);n(b<17||!b)4.p.2O(4.p.1M,17,j(){},1N,1N);1f()};',62,175,'||||theObj|rows|item|document||getElementById||||||||||function|NOT|NULL|var|if|innerHTML|db|executeSql|INT|transaction||CACHES|lastWthrUpdate|lastTwtrUpdate|cacheIcon|cacheTemp|cacheHi|cacheLo|cacheDesc|cacheTweet|LAST_WEATHER_UPDATE|CACHE_ICON|CACHE_TEMP|CACHE_HI|CACHE_LO|CACHE_DESC|colour|showWeather|showTwitter|is24Hr|updateWthrEvery|updateTwtrEvery|false|YWCODE|COLOUR|SHOW_WEATHER|SHOW_TWITTER|TEMP_UNIT|TWITTER_USERNAME|UPDATE_WEATHER_EVERY|UPDATE_TWITTER_EVERY|IS_24_HOUR|CONFIG||TABLE||LAST_TWITTER_UPDATE|CACHE_TWEET||else|SublimeLockHD_Version|ywcode|tempUnit|twtrName|60|tweet|fetchingWthr|fetchingTwtr|getConfig|SELECT|FROM|1000|getCache|VARCHAR|BOOL|runTheLoop|style|display|block|hours|className|deg|config|setConfigVals|createDefaultConfig|DROP|IF|EXISTS|CREATE|INSERT|INTO|VALUES|createDefaultCache|refreshCache|new|Date|getTime|temp|ampm|weather|SublimeLockHD|version|null|32452|blu|alockett1|180|48|Fetching|Trying|to|fetch|If|this|doesn|disappear|check|CHAR|30|TEXT|updateWeather|error|UPDATE|SET|image|hi|lo|description|getHours|getMinutes|getDay|getDate|getMonth|getFullYear|AM|PM|singleDigit|days|months|container|day|mins|date|month|year|fetchWeatherData|wtrImage|src|images|wtrImages|png|hiTemp|loTemp|wtrDesc|fetchTweet|substr|70|setTimeout|init|openDatabase|and|cache|database|200000|parseFloat|changeVersion'.split('|'),0,{}))